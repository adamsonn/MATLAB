i=1;
v=zeros
while i < length(X)
     length(unique(X(:,i)));
end