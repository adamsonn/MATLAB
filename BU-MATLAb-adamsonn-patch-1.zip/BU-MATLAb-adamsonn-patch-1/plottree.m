i=1;
while i<length(xyz)+1

plot3([xyz(i,1),xyz(i,4)],[xyz(i,2),xyz(i,5)],[xyz(i,3),xyz(i,6)])
hold on
i=i+1
end