function [mimProp] = IDtoProbability(Pathdepth,pathnumber)
IDnumb=Pathback(Pathdepth,pathnumber)
end

